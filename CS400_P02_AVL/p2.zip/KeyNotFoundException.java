/**
 * Checked exception thrown when a non existent key is specified for get or remove.
 * DO NOT EDIT THIS CLASS
 */
@SuppressWarnings("serial")
public class KeyNotFoundException extends Exception {

}
